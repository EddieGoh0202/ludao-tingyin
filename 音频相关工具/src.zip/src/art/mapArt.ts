import Phaser from 'phaser';
import { PALETTE, box, layer, poly } from './common';

/** 厦门本岛 / 鼓浪屿 / 大陆海岸轮廓，坐标与 content/scenes.json 的 mapPos 对齐（480×270）。 */
const ISLAND = [
  205, 95, 240, 70, 290, 62, 345, 68, 395, 85, 420, 115, 418, 160, 400, 195, 370, 222, 335, 232,
  290, 226, 255, 214, 225, 195, 195, 178, 185, 155, 192, 120,
];
const GULANGYU = [138, 166, 152, 161, 163, 167, 166, 179, 156, 189, 142, 186, 135, 176];
const MAINLAND = [
  0, 0, 480, 0, 480, 30, 430, 40, 380, 42, 330, 38, 280, 44, 240, 50, 200, 60, 160, 80, 130, 110,
  100, 140, 70, 160, 40, 170, 0, 176,
];

const LAND = 0xd9c99a;
const SAND = 0xeedcae;
const ROAD = 0xb59e72;

/** 以质心为基准缩放多边形，用来做沙滩描边 / 内陆层次。 */
function shrink(points: number[], factor: number): number[] {
  let cx = 0;
  let cy = 0;
  const n = points.length / 2;
  for (let i = 0; i < points.length; i += 2) {
    cx += points[i];
    cy += points[i + 1];
  }
  cx /= n;
  cy /= n;
  return points.map((v, i) => (i % 2 === 0 ? cx + (v - cx) * factor : cy + (v - cy) * factor));
}

/** 简单的确定性伪随机，保证每次绘制的波纹位置一致。 */
function rng(seed: number): () => number {
  let s = seed;
  return () => {
    s = (s * 1103515245 + 12345) & 0x7fffffff;
    return s / 0x7fffffff;
  };
}

/** 480×270 像素风厦门地图，所有图层 scrollFactor 0、depth 0–5。 */
export function drawWorldMap(scene: Phaser.Scene): void {
  // 0：海面与经纬网格
  const sea = layer(scene, 0, 0);
  box(sea, PALETTE.seaDeep, 0, 0, 480, 270);
  box(sea, PALETTE.sea, 0, 0, 480, 200);
  box(sea, PALETTE.sea, 120, 140, 360, 110, 0.6);
  for (let x = 40; x < 480; x += 40) box(sea, PALETTE.seaLight, x, 0, 1, 270, 0.12);
  for (let y = 30; y < 270; y += 40) box(sea, PALETTE.seaLight, 0, y, 480, 1, 0.12);

  // 1：波纹
  const waves = layer(scene, 1, 0);
  const rand = rng(7);
  for (let i = 0; i < 70; i++) {
    const x = 10 + rand() * 460;
    const y = 20 + rand() * 240;
    box(waves, PALETTE.seaLight, x, y, 3, 1, 0.7);
    box(waves, PALETTE.seaLight, x + 3, y - 1, 2, 1, 0.7);
    box(waves, PALETTE.seaLight, x + 5, y, 3, 1, 0.7);
  }

  // 2：陆地（大陆、本岛、鼓浪屿），先铺沙滩再铺内陆
  const land = layer(scene, 2, 0);
  poly(land, SAND, MAINLAND);
  poly(land, 0xc7b98a, [0, 0, 480, 0, 480, 24, 400, 32, 300, 30, 220, 42, 150, 72, 100, 120, 50, 150, 0, 162]);
  poly(land, PALETTE.leafDark, [0, 0, 120, 0, 80, 40, 30, 70, 0, 80], 0.55);
  poly(land, PALETTE.leafDark, [330, 0, 480, 0, 480, 18, 400, 22], 0.45);
  poly(land, SAND, ISLAND);
  poly(land, LAND, shrink(ISLAND, 0.95));
  poly(land, SAND, GULANGYU);
  poly(land, LAND, shrink(GULANGYU, 0.82));

  // 3：绿地、湖泊、道路
  const detail = layer(scene, 3, 0);
  // 万石山 / 南普陀后山
  poly(detail, PALETTE.leaf, [235, 175, 260, 165, 295, 170, 310, 190, 290, 205, 255, 200], 0.85);
  poly(detail, PALETTE.leafDark, [255, 178, 272, 172, 290, 182, 278, 194, 260, 190], 0.8);
  // 狐尾山 / 仙岳山
  poly(detail, PALETTE.leaf, [250, 95, 280, 88, 300, 100, 285, 112, 255, 110], 0.8);
  poly(detail, PALETTE.leafLight, [330, 110, 360, 104, 372, 120, 350, 130, 332, 124], 0.8);
  // 鼓浪屿日光岩绿荫
  box(detail, PALETTE.leaf, 145, 170, 10, 8, 0.85);
  // 筼筜湖
  poly(detail, PALETTE.seaLight, [222, 108, 240, 104, 248, 112, 236, 118, 220, 116]);
  // 北部机场跑道
  box(detail, PALETTE.stoneDark, 360, 78, 42, 4);
  box(detail, PALETTE.stone, 362, 79, 38, 1);
  // 道路
  detail.lineStyle(1, ROAD, 1);
  detail.lineBetween(200, 160, 215, 128);
  detail.lineBetween(215, 128, 260, 72);
  detail.lineBetween(215, 128, 300, 150);
  detail.lineBetween(200, 160, 300, 150);
  detail.lineBetween(300, 150, 400, 130);
  detail.lineBetween(300, 150, 330, 215);
  detail.lineBetween(265, 200, 330, 215);
  detail.lineBetween(200, 160, 265, 200);
  detail.lineBetween(330, 215, 395, 190);
  detail.lineBetween(400, 130, 395, 190);
  // 环岛路沙滩
  detail.lineStyle(1, 0xfff1c8, 0.9);
  detail.lineBetween(300, 226, 365, 220);
  detail.lineBetween(365, 220, 398, 193);

  // 4：跨海大桥（厦门大桥 + 海沧大桥）与轮渡航线
  const bridge = layer(scene, 4, 0);
  bridge.lineStyle(2, PALETTE.stoneDark, 1);
  bridge.lineBetween(262, 66, 258, 45);
  bridge.lineBetween(194, 112, 137, 100);
  bridge.lineStyle(1, PALETTE.cream, 1);
  bridge.lineBetween(262, 66, 258, 45);
  bridge.lineBetween(194, 112, 137, 100);
  for (let i = 1; i < 4; i++) {
    box(bridge, PALETTE.ink, 262 - i, 66 - i * 5, 3, 2);
    box(bridge, PALETTE.ink, 194 - i * 14, 112 - i * 3, 2, 3);
  }
  box(bridge, PALETTE.flame, 164, 101, 1, 6);
  box(bridge, PALETTE.flame, 171, 102, 1, 6);
  // 鹭江轮渡虚线
  for (let i = 0; i < 5; i++) box(bridge, PALETTE.cream, 168 + i * 5, 168 - i * 2, 3, 1, 0.85);

  // 白鹭剪影
  for (const [x, y] of [
    [100, 210],
    [112, 204],
    [440, 150],
  ]) {
    box(bridge, PALETTE.cream, x, y, 2, 1);
    box(bridge, PALETTE.cream, x + 2, y + 1, 1, 1);
    box(bridge, PALETTE.cream, x + 3, y, 2, 1);
  }

  // 5：罗盘与复古地图边框
  const deco = layer(scene, 5, 0);
  const cx = 440;
  const cy = 232;
  deco.fillStyle(PALETTE.cream, 0.9).fillCircle(cx, cy, 16);
  deco.lineStyle(1, PALETTE.inkSoft, 1).strokeCircle(cx, cy, 16);
  deco.lineStyle(1, PALETTE.plasterDark, 1).strokeCircle(cx, cy, 12);
  poly(deco, PALETTE.inkSoft, [cx, cy, cx + 12, cy - 2, cx + 2, cy]);
  poly(deco, PALETTE.inkSoft, [cx, cy, cx - 12, cy + 2, cx - 2, cy]);
  poly(deco, PALETTE.inkSoft, [cx - 3, cy, cx, cy + 14, cx + 3, cy]);
  poly(deco, PALETTE.flame, [cx - 3, cy, cx, cy - 14, cx + 3, cy]);
  box(deco, PALETTE.gold, cx - 1, cy - 1, 2, 2);

  // 米黄纸边框：外框 + 墨线 + 角花
  box(deco, PALETTE.plaster, 0, 0, 480, 6);
  box(deco, PALETTE.plaster, 0, 264, 480, 6);
  box(deco, PALETTE.plaster, 0, 0, 6, 270);
  box(deco, PALETTE.plaster, 474, 0, 6, 270);
  box(deco, PALETTE.plasterDark, 0, 0, 480, 1);
  box(deco, PALETTE.plasterDark, 0, 269, 480, 1);
  box(deco, PALETTE.plasterDark, 0, 0, 1, 270);
  box(deco, PALETTE.plasterDark, 479, 0, 1, 270);
  deco.lineStyle(1, PALETTE.inkSoft, 1).strokeRect(6.5, 6.5, 467, 257);
  deco.lineStyle(1, PALETTE.brickDark, 0.8).strokeRect(8.5, 8.5, 463, 253);
  for (const [x, y] of [
    [2, 2],
    [474, 2],
    [2, 264],
    [474, 264],
  ]) {
    box(deco, PALETTE.brick, x, y, 4, 4);
    box(deco, PALETTE.gold, x + 1, y + 1, 2, 2);
  }
}
