import Phaser from 'phaser';
import { drawWorldMap } from '../art/mapArt';
import { AudioManager } from '../core/AudioManager';
import { Content } from '../core/ContentRepository';
import { EventBus } from '../core/EventBus';
import { StateStore } from '../core/StateStore';
import { CollectionSystem } from '../systems/collection/CollectionSystem';
import { Stage, el } from '../ui/dom';

/** 厦门地图：已解锁地点可前往，未解锁显示门槛，后续地点「敬请期待」 */
export class WorldMapScene extends Phaser.Scene {
  private root: HTMLDivElement | null = null;

  constructor() {
    super('WorldMap');
  }

  create(): void {
    drawWorldMap(this);
    this.renderDom();
    const offs = [
      EventBus.on('scene:unlocked', () => this.renderDom()),
      EventBus.on('sound:collected', () => this.renderDom()),
    ];

    const esc = this.input.keyboard?.addKey(Phaser.Input.Keyboard.KeyCodes.ESC);
    esc?.on('down', () => this.scene.start('Location', { sceneId: StateStore.data.currentScene }));

    this.events.once(Phaser.Scenes.Events.SHUTDOWN, () => {
      offs.forEach((off) => off());
      this.root?.remove();
      this.root = null;
    });
  }

  /** 构建（或重建）地图上的 DOM 节点，解锁/收集变化时调用 */
  private renderDom(): void {
    this.root?.remove();
    const data = StateStore.data;
    const count = StateStore.collectedCount();
    this.root = el('div');
    this.root.append(el('div', { class: 'map-title', text: `厦门 · Ē-mn̂g  （已收集 ${count}/${CollectionSystem.total()}）` }));

    for (const sc of Content.scenes) {
      const unlocked = data.unlockedScenes.includes(sc.id);
      const current = sc.id === data.currentScene;
      const sub = unlocked
        ? `${CollectionSystem.countInScene(sc.id)}/${Content.soundsIn(sc.id).length} 段`
        : `收集 ${sc.unlock.requireCollected} 段解锁`;
      const label = el('div', { class: 'map-label' }, [sc.name, el('small', { text: sub })]);
      const pin = el('button', { class: `map-pin ${current ? 'current' : ''} ${unlocked ? '' : 'locked'}`, title: sc.desc }, [
        el('div', { class: 'map-dot' }),
        label,
      ]);
      Stage.place(pin, sc.mapPos.x, sc.mapPos.y);
      pin.addEventListener('click', () => {
        if (!unlocked) {
          AudioManager.sfx('bad');
          EventBus.emit('toast', { text: `${sc.name}：再收集 ${sc.unlock.requireCollected - count} 段声音就能解锁` });
          return;
        }
        AudioManager.sfx('click');
        this.scene.start('Location', { sceneId: sc.id });
      });
      this.root.append(pin);
    }

    for (const up of Content.upcoming) {
      const pin = el('div', { class: 'map-pin upcoming' }, [
        el('div', { class: 'map-dot' }),
        el('div', { class: 'map-label' }, [up.name, el('small', { text: '敬请期待' })]),
      ]);
      Stage.place(pin, up.x, up.y);
      this.root.append(pin);
    }

    const back = el('button', { class: 'btn map-back', text: '返回' });
    back.addEventListener('click', () => {
      AudioManager.sfx('click');
      this.scene.start('Location', { sceneId: data.currentScene });
    });
    this.root.append(back);
    Stage.layer('labels').append(this.root);
  }
}
