import { XIAMEN_TONE_CONTOUR, tonesOf } from '../learning/tailo';

export type Sfx = 'click' | 'lock' | 'ok' | 'bad' | 'collect' | 'dice' | 'unlock';

/**
 * 音频管理：收音机杂音 + 人声（占位合成）+ 低通滤波。
 * 正式版本中 playPhrase 应改为播放母语者录音（SoundEntry.audio）。
 */
class AudioManagerImpl {
  private ctx: AudioContext | null = null;
  private master!: GainNode;
  private noiseGain!: GainNode;
  private voiceGain!: GainNode;
  private voiceFilter!: BiquadFilterNode;
  private cleanBus!: GainNode;
  private noiseSrc: AudioBufferSourceNode | null = null;
  private loopKey: string | null = null;
  private loopTimer: number | null = null;
  private volume = 0.8;

  get ready(): boolean {
    return this.ctx !== null;
  }

  /** 必须在用户手势中调用 */
  init(): void {
    if (this.ctx) {
      void this.ctx.resume();
      return;
    }
    const Ctx = window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!Ctx) return;
    const ctx = new Ctx();
    this.ctx = ctx;
    this.master = ctx.createGain();
    this.master.gain.value = this.volume;
    this.master.connect(ctx.destination);

    this.noiseGain = ctx.createGain();
    this.noiseGain.gain.value = 0;
    const noiseBand = ctx.createBiquadFilter();
    noiseBand.type = 'bandpass';
    noiseBand.frequency.value = 2200;
    noiseBand.Q.value = 0.4;
    this.noiseGain.connect(noiseBand).connect(this.master);

    this.voiceFilter = ctx.createBiquadFilter();
    this.voiceFilter.type = 'lowpass';
    this.voiceFilter.frequency.value = 400;
    this.voiceGain = ctx.createGain();
    this.voiceGain.gain.value = 0;
    this.voiceFilter.connect(this.voiceGain).connect(this.master);

    this.cleanBus = ctx.createGain();
    this.cleanBus.gain.value = 1;
    this.cleanBus.connect(this.master);
  }

  setVolume(v: number): void {
    this.volume = v;
    if (this.ctx) this.master.gain.setTargetAtTime(v, this.ctx.currentTime, 0.05);
  }

  radioOn(on: boolean): void {
    const ctx = this.ctx;
    if (!ctx) return;
    if (on && !this.noiseSrc) {
      const len = ctx.sampleRate * 2;
      const buf = ctx.createBuffer(1, len, ctx.sampleRate);
      const data = buf.getChannelData(0);
      for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
      const src = ctx.createBufferSource();
      src.buffer = buf;
      src.loop = true;
      src.connect(this.noiseGain);
      src.start();
      this.noiseSrc = src;
    } else if (!on) {
      this.noiseSrc?.stop();
      this.noiseSrc = null;
      this.setVoiceLoop(null);
      this.setMix(0, 0, 400);
    }
  }

  /** 杂音音量、人声音量、低通截止频率 */
  setMix(noise: number, voice: number, cutoff: number): void {
    const ctx = this.ctx;
    if (!ctx) return;
    const t = ctx.currentTime;
    this.noiseGain.gain.setTargetAtTime(noise * 0.35, t, 0.05);
    this.voiceGain.gain.setTargetAtTime(voice, t, 0.05);
    this.voiceFilter.frequency.setTargetAtTime(cutoff, t, 0.05);
  }

  /** 在收音机通道中循环播放某句话（经过滤波） */
  setVoiceLoop(tailo: string | null): void {
    if (tailo === this.loopKey) return;
    if (this.loopTimer !== null) window.clearTimeout(this.loopTimer);
    this.loopTimer = null;
    this.loopKey = tailo;
    if (!tailo || !this.ctx) return;
    const loop = () => {
      if (this.loopKey !== tailo) return;
      const dur = this.synthPhrase(tailo, this.voiceFilter);
      this.loopTimer = window.setTimeout(loop, (dur + 0.8) * 1000);
    };
    loop();
  }

  /** 清晰播放一句（挑战、收集簿用），返回时长（秒） */
  playPhrase(tailo: string, rate = 1): number {
    if (!this.ctx) return 0;
    void this.ctx.resume();
    return this.synthPhrase(tailo, this.cleanBus, rate);
  }

  /** 播放单个调类的示意音 */
  playTone(tone: number): number {
    if (!this.ctx) return 0;
    return this.synthSyllables([tone], this.cleanBus, 1.4);
  }

  private synthPhrase(tailo: string, dest: AudioNode, rate = 1): number {
    const tones = tonesOf(tailo);
    return this.synthSyllables(tones.length ? tones : [1], dest, rate);
  }

  /** 占位合成：按厦门腔调值生成音高轮廓（不是真人发音） */
  private synthSyllables(tones: number[], dest: AudioNode, rate: number): number {
    const ctx = this.ctx!;
    let t = ctx.currentTime + 0.05;
    const pitch = (level: number) => 130 * Math.pow(2, (level - 1) / 4);
    for (const tone of tones) {
      const c = XIAMEN_TONE_CONTOUR[tone] ?? XIAMEN_TONE_CONTOUR[1];
      const dur = (c.short ? 0.16 : 0.32) * rate;
      const osc = ctx.createOscillator();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(pitch(c.from), t);
      osc.frequency.linearRampToValueAtTime(pitch(c.to), t + dur);
      const formant = ctx.createBiquadFilter();
      formant.type = 'bandpass';
      formant.frequency.value = 900;
      formant.Q.value = 1.2;
      const env = ctx.createGain();
      env.gain.setValueAtTime(0, t);
      env.gain.linearRampToValueAtTime(0.9, t + 0.03);
      env.gain.setValueAtTime(0.9, t + dur - (c.short ? 0.02 : 0.08));
      env.gain.linearRampToValueAtTime(0, t + dur);
      osc.connect(formant).connect(env).connect(dest);
      osc.start(t);
      osc.stop(t + dur + 0.02);
      t += dur + 0.07 * rate;
    }
    return t - ctx.currentTime;
  }

  sfx(kind: Sfx): void {
    const ctx = this.ctx;
    if (!ctx) return;
    const seq: Record<Sfx, Array<[number, number]>> = {
      click: [[880, 0.04]],
      lock: [[660, 0.08], [990, 0.12]],
      ok: [[784, 0.08], [1046, 0.14]],
      bad: [[220, 0.18]],
      collect: [[523, 0.08], [659, 0.08], [784, 0.08], [1046, 0.2]],
      dice: [[300, 0.03], [420, 0.03], [360, 0.03]],
      unlock: [[392, 0.1], [523, 0.1], [784, 0.25]],
    };
    let t = ctx.currentTime;
    for (const [f, d] of seq[kind]) {
      const osc = ctx.createOscillator();
      osc.type = 'square';
      osc.frequency.value = f;
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.12, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + d);
      osc.connect(g).connect(this.cleanBus);
      osc.start(t);
      osc.stop(t + d);
      t += d;
    }
  }
}

export const AudioManager = new AudioManagerImpl();
